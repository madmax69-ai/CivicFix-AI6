# CivicFix AI — easiest phone-only GitHub build

This package is designed so you only need to upload TWO files to a new GitHub repository:

1. `civicfix-ai.zip` — your original AI Studio project
2. `.github/workflows/build-apk.yml` — the workflow

The workflow extracts the project in GitHub Actions, installs JDK 17 and Gradle 9.3.1, creates a temporary debug keystore, injects the Gemini key from a GitHub Actions secret, builds the debug APK, and uploads the APK as an artifact.

Add this repository secret before running the workflow:

`GEMINI_API_KEY`

Then go to Actions → Build CivicFix AI APK → Run workflow.
